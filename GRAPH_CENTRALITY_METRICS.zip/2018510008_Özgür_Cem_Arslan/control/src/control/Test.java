package control;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.PriorityQueue;

import control.Graph;

public class Test {
	private static int cloindexcounter = 0;
	private static int counter = 0;
	private static int[][]betwennes=new int[34][2];
	private static int [][] closeness=new int[34][2];
	private static double clocounter=0;
	private static int betcounter=0;
	private static int indexcounter=0;

	public static Graph graphFromFile(int graphSize, String inputFilePath) throws FileNotFoundException {
		List<String> input = IO.readFile(inputFilePath);
		Graph g = new Graph(graphSize,inputFilePath);
		for (String line : input) {
			String[] elements = line.split(" ");
			g.addEdge(Integer.parseInt(elements[0]), Integer.parseInt(elements[1]));

		}
		return g;
	}

	public static void main(String[] args) throws FileNotFoundException {
		
		String inputFilePath = "karate_club_network.txt";
		Graph karete = graphFromFile(35, inputFilePath);
		
		
		for (int i = 1; i <= 34; i++) {
			for (int j = i + 1; j <= 34; j++) {
				ShortestPaths(karete, i, j);
			}

		}
		//I got this part of the code in the comment line because I broke some places while trying to fix some places in my code
		/*
		String inputFilePath2 = "facebook_social_network.txt";
		Graph facebook = graphFromFile(1519, inputFilePath2);
		
		for (int i = 1; i <= 1518; i++) {
			for (int j = i + 1; j <= 1518; j++) {
				ShortestPaths(facebook, i, j);
			}

		}
		*/
		System.out.println("Zachary Karate Club Network � The Highest Node for Betweennes    :"+indexcounter+"          Value:"+betcounter);
		System.out.println("Zachary Karate Club Network � The Highest Node for Closeness    :"+cloindexcounter+"          Value:"+1/clocounter);
		
		

	}

	public static void ShortestPaths(Graph graph, int startVertex, int endVertex) {

		int vertexCount = graph.getVertexCount();

		// storing distances of vertices removed from Queue
		float[] distances = new float[vertexCount];
		// storing predecessors ids of vertices removed from Queue
		int[] predecessors = new int[vertexCount];
		// set predecessors to -1 value, -1 means that it is a starting vertex
		Arrays.fill(predecessors,1);

		// set up PQ with vertices
		PriorityQueue<Vertex> Q = new PriorityQueue<Vertex>();
		for (int i = 0; i < vertexCount; i++) {
			if (i != startVertex)
				Q.add(new Vertex(i));
		}

		// adding start vertex and setting its distance to self for 0
		Vertex node = new Vertex(startVertex);
		node.setDistance(0);
		Q.add(node);

		// go through all vertices
		while (!Q.isEmpty()) {
			// workaround for priority queue refreshing
			if (!Q.isEmpty()) {
				Q.add(Q.remove());
			}
			// using PQ property to get vertex with shortest distance
			Vertex u = Q.remove();
			distances[u.getId()] = u.getDistance();

			// iterate through all neighbours
			Iterator<Edge> it = graph.getNeighbours(u.getId()).iterator();
			while (it.hasNext()) {
				Edge e = it.next();
				Iterator<Vertex> it2 = Q.iterator();
				while (it2.hasNext()) {
					Vertex v = it2.next();
					// checking if vertex was already visited
					if (e.getVertexB() != v.getId()) {
						continue;
					}
					// distance checking
					if (v.getDistance() > u.getDistance() + e.getWeight()) {
						v.setDistance(u.getDistance() + e.getWeight());
						v.setPredecessor(u);
						predecessors[v.getId()] = v.getPredecessor().getId();
					}
				}
			}
		}
		System.out.println("Shortest path from " + startVertex + " to " + endVertex + ":");

		List<Integer> path = new ArrayList<Integer>();
		path.add(endVertex);
		int tmpVertex = endVertex;
		int k=1;
		for (int i = 0; i < 34; i++) 
		{
			closeness[i][0]=i+1;	
		}
		while (tmpVertex != startVertex) {
			for (int i = 0; i < 34; i++) {
				betwennes[i][0]=i+1;
				if (betwennes[i][0]==startVertex) {
					betwennes[i][1]++;
				}
				if (betwennes[i][0]==tmpVertex) {
					betwennes[i][1]++;
				}
			}
			path.add(predecessors[tmpVertex]);
			tmpVertex = predecessors[tmpVertex];
			k++;
			for (int i = 0; i < 34; i++) {
				if (closeness[i][0]==startVertex&&k!=0) {
					closeness[i][1]+=k;
				}
				if (closeness[i][0]==tmpVertex&&k!=1) {
					closeness[i][1]+=k-1;
				}
			}
			
		}

		// print the path arr backwards to show to real path
		ListIterator li = path.listIterator(path.size());
		while (li.hasPrevious()) {
			counter++;
			System.out.print(li.previous());
			if (li.hasPrevious())
				System.out.print(" -> ");
		}
		System.out.println();
		for (int i = 0; i < 34; i++) {
			betcounter=0;
			if (betwennes[i][1]>betcounter) 
			{
				betcounter=betwennes[i][1];
				indexcounter=i;
			}
		}
		for (int i = 0; i < 34; i++) {
			clocounter=0;
			if (closeness[i][1]!=0&&closeness[i][1]>clocounter) 
			{
				clocounter=closeness[i][1];
				cloindexcounter=i;
			}
		}
	}

}
