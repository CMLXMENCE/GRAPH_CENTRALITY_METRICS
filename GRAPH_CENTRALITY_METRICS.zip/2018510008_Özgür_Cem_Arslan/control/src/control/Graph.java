package control;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.PriorityQueue;

/**
 * This is a model to hold indirected, weighed graph informations. Along with
 * methods for adding, removing edges and printing the graph
 */

public class Graph {
	public static ArrayList<Node> nodes = new ArrayList<>();
	private ArrayList<int[]> edges = new ArrayList<>();
	private ArrayList<HashSet<Integer>> adjList = new ArrayList<>();
	private Hashtable<Integer, Integer> vertices = new Hashtable<>();
	private Hashtable<Integer, Integer> verticesIndex = new Hashtable<>();

	public ArrayList<Node> getNodes() {
		return nodes;
	}

	public void setNodes(ArrayList<Node> nodes) {
		this.nodes = nodes;
	}

	public void addNode(Node node) {
		nodes.add(node);
	}

	private int vertexCount;
	private PriorityQueue<Edge>[] adjacency;

	public int getVertexCount() {
		return vertexCount;
	}

	public int getNumberOfVertices() {
		return vertices.size();
	}


	public void generateAdjList() {

		int count = 0;
		for (int[] line : edges) {
			int[] vertex = line;
			if (!verticesIndex.containsKey(vertex[0])) {
				verticesIndex.put(vertex[0], count);
				vertices.put(count, vertex[0]);
				adjList.add(count, new HashSet<>());
				count++;
			}
			if (!verticesIndex.containsKey(vertex[1])) {
				verticesIndex.put(vertex[1], count);
				vertices.put(count, vertex[1]);
				adjList.add(count, new HashSet<>());
				count++;
			}
		}
		for (int i = 0; i < edges.size(); i++) {

			int node1 = verticesIndex.get(edges.get(i)[0]);
			int node2 = verticesIndex.get(edges.get(i)[1]);
			HashSet<Integer> connect1 = adjList.get(node1);
			HashSet<Integer> connect2 = adjList.get(node2);
			if (!connect1.contains(node2)) {
				adjList.get(node1).add(node2);
			}
			if (!connect2.contains(node1)) {
				adjList.get(node2).add(node1);
			}
		}

	}

	public int getVertex(int index) {
		return vertices.get(index);
	}

	public ArrayList<HashSet<Integer>> getAdjList() {
		ArrayList<HashSet<Integer>> adjListClone = new ArrayList<>();
		for (int i = 0; i < adjList.size(); i++) {
			adjListClone.add(new HashSet<Integer>(adjList.get(i)));
			generateAdjList();
		}
		return adjListClone;
	}

	public Graph(int vertexCount, String filename) throws FileNotFoundException {
		this.vertexCount = vertexCount;
		// initialize adjacency as PQ
		adjacency = new PriorityQueue[vertexCount];
		for (int i = 0; i < vertexCount; i++) {
			adjacency[i] = new PriorityQueue<Edge>();
		}
		readEdgeList(filename);

		generateAdjList();
	}

	private void readEdgeList(String filename) throws FileNotFoundException {
		try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] l = line.split(" ");
				int[] array = new int[2];
				array[0] = Integer.parseInt(l[0]);
				array[1] = Integer.parseInt(l[1]);
				edges.add(array);
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("--Error, Cant read file-- " + e.getMessage());
			throw new FileNotFoundException("Not found");
		}
	}

	public void addEdge(int a, int b) {
		adjacency[a].add(new Edge(a, b));
		adjacency[b].add(new Edge(b, a));
	}

	public void addEdge(Edge e) {
		adjacency[e.getVertexA()].add(e);
	}

	public boolean containsEdge(Edge e) {
		return adjacency[e.getVertexA()].contains(e);
	}

	public void removeEdge(int a, int b) {
		Iterator<Edge> it = adjacency[a].iterator();
		Edge tmpEdge = new Edge(a, b);

		while (it.hasNext()) {
			if (it.next().equals(tmpEdge))
				it.remove();
		}
	}

	public PriorityQueue<Edge> getNeighbours(int vertex) {
		return adjacency[vertex];
	}

	public void printGraph() {
		for (int i = 0; i < vertexCount; i++) {
			PriorityQueue<Edge> edges = getNeighbours(i);
			Iterator<Edge> it = edges.iterator();
			System.out.print(i + ": ");
			for (int j = 0; j < edges.size(); j++) {
				System.out.print(it.next() + " ");
			}
			System.out.println();
		}
	}

}
