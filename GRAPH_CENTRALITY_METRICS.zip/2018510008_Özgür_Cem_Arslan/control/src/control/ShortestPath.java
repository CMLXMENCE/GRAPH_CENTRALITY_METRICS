package control;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Collections;

class ShortestPath {
	Node start, end;

	ShortestPath(Node start, Node end) {
		this.start = start;
		this.end = end;
	}

	public void bfs() {
		// Create queue
		Queue<Node> queue = new LinkedList<>();

		// Visit and add start node to the queue
		start.visited = true;
		queue.add(start);

		// BFS until queue is empty and not reached to the end node
		while (!queue.isEmpty()) {
			// pop a node from queue for search operation
			Node current_node = queue.poll();
			// Loop through neighbors node to find the 'end'
			for (Node node : current_node.neighbors) {
				if (!node.visited) {
					// Visit and add the node to the queue
					node.visited = true;
					queue.add(node);
					// update its precedings nodes
					node.prev = current_node;
					// If reached the end node then stop BFS
					if (node == end) {
						queue.clear();
						break;
					}
				}
			}
		}
		trace_route();
	}

	// Function to trace the route using preceding nodes
	private void trace_route() {
		Node node = end;
		List<Node> route = new ArrayList<>();
		// Loop until node is null to reach start node
		// becasue start.prev == null
		while (node != null) {
			route.add(node);
			node = node.prev;
		}
		// Reverse the route - bring start to the front
		Collections.reverse(route);
		// Output the routes
		System.out.println(route);
		for (int i = 1; i < Graph.nodes.size(); i++) {
			Graph.nodes.get(i).visited = false;
		}

	}

}