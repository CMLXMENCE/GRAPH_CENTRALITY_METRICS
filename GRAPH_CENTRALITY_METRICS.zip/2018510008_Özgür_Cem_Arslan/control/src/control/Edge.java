package control;


public class Edge implements Comparable{

    private int vertexA;
    private int vertexB;
    private float weight;

    public Edge (int vertexA, int vertexB) {
        this.vertexA = vertexA;
        this.vertexB = vertexB;
    }

    public int getVertexA() {
        return vertexA;
    }

    public int getVertexB() {
        return vertexB;
    }

    public float getWeight() {
        return weight;
    }

    public boolean equals(Edge otherEdge) {
        if (this.vertexA == otherEdge.vertexA && this.vertexB == otherEdge.vertexB) {
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public int compareTo(Object o) {
        Edge otherEdge = (Edge) o;
        return Double.compare(this.weight, otherEdge.weight);
    }

    public String toString() {
        return vertexA + " -- " + vertexB + " (" + weight + "); ";
    }
}
