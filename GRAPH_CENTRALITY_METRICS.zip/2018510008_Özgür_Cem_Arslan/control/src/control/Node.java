package control;

import java.util.*;
class Node{
  String name;
  List<Node> neighbors;
  boolean visited = false;
  Node prev = null;
  

  Node(String name){
    this.name = name;
    this.neighbors = new ArrayList<>();
  }

  //Method to connect nodes
  void add_neighbor(Node node){
    this.neighbors.add(node);
    node.neighbors.add(this);
  }

  //Node representation
  public String toString(){
    return this.name;
  }
}